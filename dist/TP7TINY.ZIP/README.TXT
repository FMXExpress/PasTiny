PasTiny - Turbo Pascal 7 real-mode build

TINY.EXE: integer engine, 8086 BASM dot products
TNYFLT.EXE: float comparison engine
TNYNO.EXE: integer engine, pure Pascal dot products
TINY.BIN: unchanged upstream model; keep in the current directory

Run TINY 0 for the DOS interface, TINY 0 /P for plain mode,
or TINY /BENCH > BENCH.TXT. All entries use uppercase 8.3 names.
No CWSDPMI.EXE or WMEMU387.DXE is required. TP7 floating-point
emulation is compiled in. Physical Pocket386 hardware is untested.

All three variants match 60/60 answers in DOSBox-X with FPU enabled.
The integer benchmark also passes all 5 questions with fpu=false.
See https://github.com/FMXExpress/PasTiny for test evidence and limits.

BUILD.BAT uses your own TPC.EXE or BPC.EXE; no compiler is included.
Based on WollyMonjac/Tiny-2.1 commit 1d5cf54677addf188a090ca1c91acb3d02989a1d.
LICENSE.TXT covers repository contributions; it does not change upstream terms.
