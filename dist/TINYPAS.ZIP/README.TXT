PasTiny - Pascal TINY 2.1 port

Run TINY 0 for the DOS interface, TINY 0 /P for plain mode,
and TINY /BENCH > BENCH.TXT for a benchmark.
Keep TINY.BIN, CWSDPMI.EXE and WMEMU387.DXE beside TINY.EXE.

TINY.EXE is the integer build. TNYFLT.EXE is the float build.
BUILDFPC.BAT builds with Free Pascal 3.2.2 for DOS.
BUILD.BAT contains TP7/BP7 commands, not yet verified.

This archive uses only uppercase 8.3 names. Host tests and the
full validation report are in https://github.com/FMXExpress/PasTiny .
No-FPU/Pocket386 operation remains unverified.

Based on WollyMonjac/Tiny-2.1 revision 1d5cf54677addf188a090ca1c91acb3d02989a1d.
Original model and third-party runtime terms are not changed by LICENSE.TXT.
Runtime notices: CWSDPMI.TXT, COPYFPC.TXT, COPYDJ.TXT and COPYING.
CWSDPMI source/updates: https://sandmann.dotster.com/cwsdpmi/
FPC/DJGPP runtime distribution: https://www.freepascal.org/
